// Custom setup for 3.5" ILI9488 SPI TFT + touch on ESP32 DevKit V1

#define ILI9488_DRIVER

// ==== SPI TFT pins ====
#define TFT_MISO 19      // SDO
#define TFT_MOSI 23      // SDI
#define TFT_SCLK 18      // SCK
#define TFT_CS   15      // Chip select
#define TFT_DC   2       // Data/command
#define TFT_RST  5       // Reset

// ==== Touch (XPT2046) ====
#define TOUCH_CS 21      // Touch chip select
// #define TOUCH_IRQ 22   // If you wired IRQ, uncomment and set pin

// ==== SPI speeds ====
#define SPI_FREQUENCY       40000000
#define SPI_TOUCH_FREQUENCY 2500000

// ==== Colour/offset options ====
#define CGRAM_OFFSET
#define TFT_RGB_ORDER TFT_BGR
// Make sure we are in SPI mode, not parallel:
//// #define TFT_PARALLEL_8_BIT
